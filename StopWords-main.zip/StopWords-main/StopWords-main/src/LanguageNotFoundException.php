<?php

declare(strict_types=1);

namespace StopWords;

use Exception;

class LanguageNotFoundException extends Exception
{

}
